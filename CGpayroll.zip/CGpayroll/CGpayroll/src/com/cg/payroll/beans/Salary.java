package com.cg.payroll.beans;
public class Salary {
	private float basicSalary, hra, conveyenceAllowance, otherAllowance,personalAllowance,monthlyTax, epf,
	companyPf,gratuity,grossSalary,netSalary ;
	public Salary(){}
	
	public Salary(float basicSalary, float epf, float companyPf) {
		super();
		this.basicSalary = basicSalary;
		this.epf = epf;
		this.companyPf = companyPf;
	}

	public Salary(float basicSalary, float hra, float conveyenceAllowance, float otherAllowance,
			float personalAllowance, float monthlyTax, float epf, float companyPf, float gratuity, float grossSalary,
			float netSalary) {
		super();
		this.basicSalary = basicSalary;
		this.hra = hra;
		this.conveyenceAllowance = conveyenceAllowance;
		this.otherAllowance = otherAllowance;
		this.personalAllowance = personalAllowance;
		this.monthlyTax = monthlyTax;
		this.epf = epf;
		this.companyPf = companyPf;
		this.gratuity = gratuity;
		this.grossSalary = grossSalary;
		this.netSalary = netSalary;
	}

	public float getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(float basicSalary) {
		this.basicSalary = basicSalary;
	}

	public float getHra() {
		return hra;
	}

	public void setHra(float hra) {
		this.hra = hra;
	}

	public float getConveyenceAllowance() {
		return conveyenceAllowance;
	}

	public void setConveyenceAllowance(float conveyenceAllowance) {
		this.conveyenceAllowance = conveyenceAllowance;
	}

	public float getOtherAllowance() {
		return otherAllowance;
	}

	public void setOtherAllowance(float otherAllowance) {
		this.otherAllowance = otherAllowance;
	}

	public float getPersonalAllowance() {
		return personalAllowance;
	}

	public void setPersonalAllowance(float personalAllowance) {
		this.personalAllowance = personalAllowance;
	}

	public float getMonthlyTax() {
		return monthlyTax;
	}

	public void setMonthlyTax(float monthlyTax) {
		this.monthlyTax = monthlyTax;
	}

	public float getEpf() {
		return epf;
	}

	public void setEpf(float epf) {
		this.epf = epf;
	}

	public float getCompanyPf() {
		return companyPf;
	}

	public void setCompanyPf(float companyPf) {
		this.companyPf = companyPf;
	}

	public float getGratuity() {
		return gratuity;
	}

	public void setGratuity(float gratuity) {
		this.gratuity = gratuity;
	}

	public float getGrossSalary() {
		return grossSalary;
	}

	public void setGrossSalary(float grossSalary) {
		this.grossSalary = grossSalary;
	}

	public float getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(float netSalary) {
		this.netSalary = netSalary;
	}
	
}